package com.example.guardiancamera_wifi;

import android.app.Service;
import android.content.Intent;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.Looper;
import android.os.Message;
import android.os.Process;
import android.util.Log;

import com.arthenica.mobileffmpeg.Config;
import com.arthenica.mobileffmpeg.FFmpeg;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.Socket;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.util.ArrayDeque;
import java.util.Arrays;
import java.util.concurrent.Semaphore;


public class CamStreamer extends Service {

    private static final int RETURN_CODE_SUCCESS = 0x00;
    private static final int RETURN_CODE_CANCEL = 0x01;
    private static boolean runState;
    private DatagramSocket mjpegCamSocket, serverSocket;
    private Socket camCommandSocket;
    OutputStream camCmdOutput;
    PrintWriter output;
    InputStream camCmdInput;

    private DatagramPacket image_packet, server_packet;
    private byte [] data;
    private Thread camThread, serverThread;
    private ArrayDeque<DatagramPacket> packetQueue = new ArrayDeque<DatagramPacket>();
    private Semaphore packetQueueSemaphore = new Semaphore(1);
    private StreamHandler streamHandler;
    private Looper serviceLooper;

    private final String IP_HOST = "192.168.43.1";
    private final String IP_CAM = "192.168.43.74";
    private final String IP_SERVER = "192.168.43.74";

    private final byte CAM_START_VIDEO = 0x40;
    private final byte CAM_STOP_VIDEO = 0x41;
    private final byte CAM_REQUEST_SERIAL_ID = 0x42;
    private final byte CAM_SET_FRAMESIZE = 0X43;

    public static boolean isRunning() {
        return runState;
    }

    public CamStreamer() {
    }

    private final class StreamHandler extends Handler {

        public StreamHandler(Looper looper) {
            super(looper);
        }

        @Override
        public void handleMessage(Message msg) {
            try {
                mjpegCamSocket = new DatagramSocket(8000, InetAddress.getByName(IP_HOST));
            } catch (SocketException | UnknownHostException e) {
                e.printStackTrace();
                stopSelf();
            }

            try {
                serverSocket = new DatagramSocket(8001, InetAddress.getByName(IP_HOST));

            } catch (SocketException | UnknownHostException e) {
                e.printStackTrace();
                stopSelf();
            }
            camThread.start();
            serverThread.start();
        }
    }


    @Override
    public void onCreate() {
        super.onCreate();
        data = new byte[1024];
        image_packet = new DatagramPacket(data,0,1024);
        server_packet = new DatagramPacket(data,0,1024);
        camThread = new Thread(){
            @Override
            public void run() {
            try {
                mjpegCamSocket.connect(InetAddress.getByName(IP_CAM),8000);

                while(true) {
                    try {
                        mjpegCamSocket.receive(image_packet);
                        packetQueueSemaphore.acquire();
                        packetQueue.add(image_packet);
                        packetQueueSemaphore.release();
                        Log.i("KAKAO_SESSION", Arrays.toString(image_packet.getData()));
                    } catch (IOException | InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            } catch (UnknownHostException e) {
                e.printStackTrace();
            }
            }
        };

        serverThread = new Thread(){
            @Override
            public void run() {
                try {
                    serverSocket.connect(InetAddress.getByName(IP_SERVER),8001);
                } catch (UnknownHostException e) {
                    e.printStackTrace();
                }
                while(true) {
                    if (!packetQueue.isEmpty()) {
                        try {
                            packetQueueSemaphore.acquire();
                            server_packet.setData(packetQueue.pop().getData());
                            Log.i("Server", Arrays.toString(server_packet.getData()));
                            serverSocket.send(server_packet);
                            packetQueueSemaphore.release();
                        } catch (IOException e) {
                            e.printStackTrace();
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                    }
                }
            }
        };

        HandlerThread handlerThread = new HandlerThread("Streaming Service Handler", Process.THREAD_PRIORITY_BACKGROUND);
        handlerThread.start();

        serviceLooper = handlerThread.getLooper();
        streamHandler = new StreamHandler(serviceLooper);
    }


    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        super.onStartCommand(intent, flags, startId);
/*
        int [] captureInfo = intent.getIntArrayExtra("FRAME_SIZE");
        if (captureInfo.length < 2)
            return START_REDELIVER_INTENT;

        try {
            camCommandSocket = new Socket(InetAddress.getByName(IP_CAM), 8000,
                    InetAddress.getByName(IP_HOST), 8000);
            camCmdOutput = camCommandSocket.getOutputStream();
            output = new PrintWriter(camCmdOutput);
            camCmdInput = camCommandSocket.getInputStream();
        } catch (UnknownHostException e) {
            e.printStackTrace();
            return START_REDELIVER_INTENT;
        } catch (IOException e) {
            e.printStackTrace();
            return START_REDELIVER_INTENT;
        }

        try {
            camCmdOutput.write(CAM_SET_FRAMESIZE);
            camCmdOutput.write(captureInfo[0]);
            camCmdOutput.write(captureInfo[0] >> 8);
            camCmdOutput.write(captureInfo[0] >> 16);
            camCmdOutput.write(captureInfo[0] >> 24);
            camCmdOutput.write(captureInfo[1]);
            camCmdOutput.write(captureInfo[1] >> 8);
            camCmdOutput.write(captureInfo[1] >> 16);
            camCmdOutput.write(captureInfo[1] >> 24);
            camCmdOutput.write(CAM_START_VIDEO);
        } catch (IOException e) {
            e.printStackTrace();
            return START_REDELIVER_INTENT;
        }
*/
        Message msg = streamHandler.obtainMessage();
        msg.arg1 = startId;
        streamHandler.sendMessage(msg);

        runState = true;

        int rc = FFmpeg.execute("-f MJPEG -i udp://192.168.43.74:8000 -c:v libx264 example.mp4");

        if (rc == RETURN_CODE_SUCCESS) {
            Log.i(Config.TAG, "Command execution completed successfully.");
        } else if (rc == RETURN_CODE_CANCEL) {
            Log.i(Config.TAG, "Command execution cancelled by user.");
        } else {
            Log.i(Config.TAG, String.format("Command execution failed with rc=%d and the output below.", rc));
            Config.printLastCommandOutput(Log.INFO);
        }

        return START_STICKY;
    }

    @Override
    public IBinder onBind(Intent intent) {
        // TODO: Return the communication channel to the service.
        throw new UnsupportedOperationException("Not yet implemented");
    }

    @Override
    public void onDestroy() {
        try {
            camCmdOutput.write(CAM_STOP_VIDEO);
        } catch (IOException e) {
            e.printStackTrace();
        }

        FFmpeg.cancel();

        runState = false;
        super.onDestroy();
    }
}
