package com.example.guardiancamera_wifi;

import android.app.ActivityManager;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;


public class MainMenuActivity extends AppCompatActivity {

    TextView captureServiceBtn;
    TextView viewVideoBtn;
    TextView peerListBtn;
    TextView settingBtn;
    ActivityManager activityManager;

    boolean camRecordingStat;
    boolean camConnectionStat;
    boolean serverConnectionStat;


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_menu);

        activityManager = (ActivityManager) getApplicationContext().getSystemService(Context.ACTIVITY_SERVICE);

        camRecordingStat = false;
        camConnectionStat = false;
        serverConnectionStat = false;

        final Intent captureIntent = new Intent(this, CamStreamer.class);
        //captureIntent.putExtra()
        captureServiceBtn = (TextView) findViewById(R.id.captureStartBtn);
        captureServiceBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
            if (!CamStreamer.isRunning())
                startService(captureIntent);
            }
        });

        final Intent videoViewIntent = new Intent(this, VideoViewActivity.class);
        viewVideoBtn = (TextView) findViewById(R.id.videoViewBtn);
        viewVideoBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(videoViewIntent);
            }
        });

        final Intent peerListIntent = new Intent(this, PeerListActivity.class);
        peerListBtn = (TextView) findViewById(R.id.peerListBtn);
        peerListBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(peerListIntent);
            }
        });

        final Intent settingIntent = new Intent(this, SettingActivity.class);
        settingBtn = (TextView) findViewById(R.id.settingBtn);
        settingBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(settingIntent);
            }
        });
    }


    @Override
    protected void onStart() {
        super.onStart();
    }


    @Override
    protected void onResume() {
        super.onResume();
    }


    @Override
    protected void onPause() {
        super.onPause();
    }

}
